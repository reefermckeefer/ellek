//
//  vitalSignsTableViewController.swift
//  
//
//  Created by Ellek Linton on 7/25/15.
//
//

import Cocoa

class vitalSignsTableViewController: UITableViewController {

}
