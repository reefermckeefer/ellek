//
//  LineChartFunctions.swift
//  Vintage Vitality
//
//  Created by Ellek Linton on 7/23/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import Foundation
import UIKit

class LineChartFunctionsX{
    var customization = customizeView()
    func createGraph(view: UIView, delegate: JBLineChartViewDelegate, chartView: JBLineChartView, dataSource: JBLineChartViewDataSource, minimumValueOfY: CGFloat, maximumValueOfY: CGFloat?, backgroundColour: UIColor, tintColour: UIColor, frame: CGRect, data: Array<CGFloat>, radius: CGFloat) -> JBLineChartView{
            chartView.delegate = delegate
            chartView.dataSource = dataSource
            chartView.minimumValue = minimumValueOfY
            if (maximumValueOfY != nil){
                chartView.maximumValue = maximumValueOfY!
            }
            chartView.backgroundColor = backgroundColour
            chartView.tintColor = tintColour
            chartView.frame = frame
            //chartView.center.x = view.center.x
            chartView.reloadData()
            addViews(view, arrayOfViewsToBeAdded: [chartView])
        
//        DELETE THIS LINE AFTER TESTING
        createAxis(view, chartView: chartView, axisColour: customization.darkGreyColour, axisHeight: radius, data: data)
        return chartView
    }
    
    func createAxis(view: UIView, chartView: JBLineChartView, axisColour: UIColor, axisHeight: CGFloat, data: Array<CGFloat>){
        let xAxis = createXAxis(view, chartView: chartView, backgroundColour: axisColour, heightOfLine: axisHeight, data: data)
        addViews(view, arrayOfViewsToBeAdded: [xAxis])
    }
    
    func createXAxis(view: UIView, chartView: JBLineChartView, backgroundColour: UIColor, heightOfLine: CGFloat, data: Array<CGFloat>) -> UILabel{
        var axis = UILabel()
        axis.backgroundColor = backgroundColour
        axis.frame = CGRectMake(chartView.frame.minX, chartView.frame.maxY, chartView.frame.width, heightOfLine)
        labelXAxis(view, axis: axis, chartView: chartView, data: data, heightOfLine: heightOfLine, backgroundColour: backgroundColour)
        return axis
    }
    
    func labelXAxis(view: UIView, axis: UILabel, chartView: JBLineChartView, data: Array<CGFloat>, heightOfLine: CGFloat, backgroundColour: UIColor) -> Array<UILabel>{
        var firstLabel = firstLabelOnAxis(axis, heightOfLine: heightOfLine, backgroundColour: backgroundColour)
//        view.addSubview(firstLabel)
        var lastLabel = lastLabelOnAxis(axis, heightOfLine: heightOfLine, backgroundColour: backgroundColour)
        view.addSubview(lastLabel)
        addTextToTickMark(view, tickMarkLabels: [lastLabel], textToAdd: ["\(data.count)"], textColour: customization.darkGreyColour, radius: heightOfLine)
        for (index, value) in enumerate(data){
            //println("\(index) \(value)")
            if (index != 0 && index != data.count - 1){
                let xCoordinates = (chartView.frame.width / CGFloat(data.count - Int(1)))
                var newLabel = makeLabelOnAxis(axis, heightOfLine: heightOfLine, backgroundColour: backgroundColour, xCoordinate: xCoordinates * CGFloat(index) + chartView.frame.minX)
                    addViews(view, arrayOfViewsToBeAdded: [newLabel])
                    addTextToTickMark(view, tickMarkLabels: [newLabel], textToAdd: ["\(index + 1)"], textColour: customization.darkGreyColour, radius: heightOfLine)
            }
        }
        return [axis]
    }
    
    func firstLabelOnAxis(axis: UILabel, heightOfLine: CGFloat, backgroundColour: UIColor) -> UILabel{
        var first = UILabel(frame: CGRectMake(axis.frame.minX, axis.frame.maxY, heightOfLine, heightOfLine * 2))
        first.backgroundColor = backgroundColour
        return first
    }
    
    func lastLabelOnAxis(axis: UILabel, heightOfLine: CGFloat, backgroundColour: UIColor) -> UILabel{
        var last = UILabel(frame: CGRectMake(axis.frame.maxX - heightOfLine, axis.frame.maxY, heightOfLine, heightOfLine * 2))
        last.backgroundColor = backgroundColour
        return last
    }
    
    func makeLabelOnAxis(axis: UILabel, heightOfLine: CGFloat, backgroundColour: UIColor, xCoordinate: CGFloat) -> UILabel{
        var label = UILabel(frame: CGRectMake(xCoordinate - (0.5 * heightOfLine), axis.frame.maxY, heightOfLine, heightOfLine * 2))
            label.backgroundColor = backgroundColour
            return label
    }
    
    func addViews(viewToAddTo: UIView, arrayOfViewsToBeAdded: Array<UIView>){
        for (index, value) in enumerate(arrayOfViewsToBeAdded){
            viewToAddTo.addSubview(arrayOfViewsToBeAdded[index])
        }
    }
    
    func addTextToTickMark(viewToAddTo: UIView, tickMarkLabels: [UILabel], textToAdd: [String], textColour: UIColor, radius: CGFloat){
        for (index, tickMarkLabel) in enumerate(tickMarkLabels){
        var textLabel = UILabel(frame: CGRectMake(tickMarkLabel.frame.midX, tickMarkLabel.frame.maxY + radius, 100, 100))
        textLabel.text = textToAdd[index]
        textLabel.font = UIFont(name: "Helvetica Neue", size: radius * 3)
        textLabel.sizeToFit()
        textLabel.center.x = tickMarkLabel.center.x
        textLabel.textColor = textColour
        textLabel.backgroundColor = UIColor.clearColor()
        addViews(viewToAddTo, arrayOfViewsToBeAdded: [textLabel])
        }
    }
}



class lineChartFunctionsY{
    var customization = customizeView()
    var xFunctions = LineChartFunctionsX()

    func createAxis(view: UIView, chartView: JBLineChartView, backgroundColour: UIColor, widthOfLine: CGFloat, data: Array<CGFloat>) -> UILabel{
        var axis = UILabel()
        axis.backgroundColor = backgroundColour
        axis.frame = CGRectMake(chartView.frame.minX, chartView.frame.minY, widthOfLine, chartView.frame.height)
        LineChartFunctionsX().addViews(view, arrayOfViewsToBeAdded: [axis])
        labelYAxis(view, axis: axis, chartView: chartView, data: data, heightOfLine: widthOfLine, backgroundColour: backgroundColour)
        return axis
    }
    
    func firstLabelOnAxis(axis: UILabel, widthOfLine: CGFloat, backgroundColour: UIColor) -> UILabel{
        var first = UILabel(frame: CGRectMake(axis.frame.minX - (widthOfLine * 2), axis.frame.maxY, widthOfLine * 2, widthOfLine))
        first.backgroundColor = backgroundColour
        return first
    }
    
    func lastLabelOnAxis(axis: UILabel, widthOfLine: CGFloat, backgroundColour: UIColor) -> UILabel{
        var last = UILabel(frame: CGRectMake(axis.frame.minX - (widthOfLine * 2), axis.frame.minY, widthOfLine * 2, widthOfLine))
        last.backgroundColor = backgroundColour
        return last
    }
    
    func labelYAxis(view: UIView, axis: UILabel, chartView: JBLineChartView, data: Array<CGFloat>, heightOfLine: CGFloat, backgroundColour: UIColor) -> Array<UILabel>{
        var firstLabel = firstLabelOnAxis(axis, widthOfLine: 0, backgroundColour: backgroundColour)
//        view.addSubview(firstLabel)
        var lastLabel = lastLabelOnAxis(axis, widthOfLine: heightOfLine, backgroundColour: backgroundColour)
        view.addSubview(lastLabel)
        var increment = maxElement(data) / CGFloat(data.count)
        addTextToTickMark(view, tickMarkLabels: [firstLabel], textToAdd: ["1"], textColour: customization.darkGreyColour, radius: heightOfLine)
        addTextToTickMark(view, tickMarkLabels: [lastLabel], textToAdd: ["\(Int(CGFloat(data.count) * increment))"], textColour: customization.darkGreyColour, radius: heightOfLine)
        for (index, value) in enumerate(data){
            //println("\(index) \(value)")
            if (index != 0 && index != data.count - 1){
                let yCoordinates = (chartView.frame.height / CGFloat(data.count - Int(1)))
                var newLabel = makeLabelOnAxis(axis, widthOfLine: heightOfLine, backgroundColour: backgroundColour, yCoordinate:  chartView.frame.maxY - yCoordinates * CGFloat(index))
                xFunctions.addViews(view, arrayOfViewsToBeAdded: [newLabel])
                println(increment)
                var tempIncrement = increment * CGFloat(index)
                addTextToTickMark(view, tickMarkLabels: [newLabel], textToAdd: ["\(Int(tempIncrement))"], textColour: customization.darkGreyColour, radius: heightOfLine)
            }
        }
        return [axis]
    }
    
    func addTextToTickMark(viewToAddTo: UIView, tickMarkLabels: [UILabel], textToAdd: [String], textColour: UIColor, radius: CGFloat){
        for (index, tickMarkLabel) in enumerate(tickMarkLabels){
            var textLabel = UILabel(frame: CGRectMake(tickMarkLabel.frame.midX, tickMarkLabel.frame.maxY + radius, 100, 100))
            textLabel.text = "\(textToAdd[index])"
            textLabel.font = UIFont(name: "Helvetica Neue", size: radius * 3)
            textLabel.sizeToFit()
            textLabel.frame = CGRectMake((tickMarkLabel.frame.minX - textLabel.frame.width - (radius * 3)), tickMarkLabel.frame.midY - (0.5 * textLabel.frame.width), textLabel.frame.width, textLabel.frame.height)
            textLabel.textColor = textColour
            textLabel.backgroundColor = UIColor.clearColor()
            xFunctions.addViews(viewToAddTo, arrayOfViewsToBeAdded: [textLabel])
        }
    }
    
    func makeLabelOnAxis(axis: UILabel, widthOfLine: CGFloat, backgroundColour: UIColor, yCoordinate: CGFloat) -> UILabel{
        var label = UILabel(frame: CGRectMake(axis.frame.minX - widthOfLine * 2, yCoordinate, widthOfLine * 2, widthOfLine))
        label.backgroundColor = backgroundColour
        return label
    }



}