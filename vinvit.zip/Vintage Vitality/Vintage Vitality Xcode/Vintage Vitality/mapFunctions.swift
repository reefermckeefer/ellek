//
//  mapFunctions.swift
//  Vintage Vitality
//
//  Created by Ellek Linton on 7/22/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class mapFunctions{
    func setCoordinate(mapView: MKMapView, latitude: CLLocationDegrees, longitude: CLLocationDegrees, regionRadius: CLLocationDistance, title: String, subtitle: String){
        let location = CLLocation(latitude: latitude, longitude: longitude)
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)
        mapView.setRegion(coordinateRegion, animated: true)
        setAnnotation(mapView, location: CLLocationCoordinate2D(latitude: latitude, longitude: longitude), title: title, subtitle: subtitle)
    }
    
    func setAnnotation(mapView: MKMapView, location: CLLocationCoordinate2D, title: String, subtitle: String){
        var annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = title
        annotation.subtitle = subtitle
        mapView.addAnnotation(annotation)
        mapView.selectAnnotation(annotation, animated: true)
    }
    
}
