//
//  View.swift
//  Vintage Vitality
//
//  Created by Ellek Linton on 7/22/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import Foundation
import UIKit

class customizeView{
    var darkRedColour = UIColor(red: 163/255, green: 29/255, blue: 33/255, alpha: 1)
    var lightRedColour = UIColor(red: 233/255, green: 60/255, blue: 65/255, alpha: 1)
    var darkGreyColour = UIColor(red: 34/255, green: 34/255, blue: 34/255, alpha: 1)
    var whiteColour = UIColor(red: 1, green: 1, blue: 1, alpha: 1)
    var clearColour = UIColor.clearColor()
    var lightGreyColour = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1)
    
func setColours(view: UIViewController){
    var selectedColour = lightRedColour
        UIApplication.sharedApplication().statusBarStyle = .LightContent
        view.view.backgroundColor = darkRedColour
        view.tabBarController?.tabBar.barTintColor = darkGreyColour
        view.tabBarController?.tabBar.tintColor = selectedColour
        view.navigationController?.navigationBar.barTintColor = darkGreyColour
        view.navigationController?.navigationBar.tintColor = whiteColour
        view.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: whiteColour]
        for item in view.tabBarController?.tabBar.items as! [UITabBarItem] {
            if let image = item.image {
                item.image = image.imageWithColor(whiteColour).imageWithRenderingMode(.AlwaysOriginal)
                item.setTitleTextAttributes([NSForegroundColorAttributeName: whiteColour], forState: .Normal)
                item.setTitleTextAttributes([NSForegroundColorAttributeName: selectedColour], forState: .Selected)
            }
        }
    }
}



extension UIImage {
    func imageWithColor(tintColor: UIColor) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        
        let context = UIGraphicsGetCurrentContext() as CGContextRef
        CGContextTranslateCTM(context, 0, self.size.height)
        CGContextScaleCTM(context, 1.0, -1.0);
        CGContextSetBlendMode(context, kCGBlendModeNormal)
        
        let rect = CGRectMake(0, 0, self.size.width, self.size.height) as CGRect
        CGContextClipToMask(context, rect, self.CGImage)
        tintColor.setFill()
        CGContextFillRect(context, rect)
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext() as UIImage
        UIGraphicsEndImageContext()
        
        return newImage
    }
}