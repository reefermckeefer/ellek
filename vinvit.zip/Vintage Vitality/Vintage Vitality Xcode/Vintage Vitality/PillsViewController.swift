//
//  PillsViewController.swift
//  Vintage Vitality
//
//  Created by Ellek Linton on 7/22/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import UIKit

class PillsViewController: UIViewController {
    var customization = customizeView()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        customization.setColours(self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
