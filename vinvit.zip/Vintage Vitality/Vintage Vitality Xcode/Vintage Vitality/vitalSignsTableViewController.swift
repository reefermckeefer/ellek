//
//  PillsViewController.swift
//  Vintage Vitality
//
//  Created by Ellek Linton on 7/22/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import UIKit

class vitalSignsViewController: UITableViewController, UITableViewDataSource, UITableViewDelegate {
    var customization = customizeView()
    var arrayOfTitles = ["Heart Rate", "Blood Pressure", "Respiration"]
    var arrayOfDetails = ["View a detailed graph", "View a detailed graph", "View a detailed graph"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        customization.setColours(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        switch indexPath.row{
            case 0:
                self.performSegueWithIdentifier("tableViewToHeartRate", sender: self)
            default:
                println("default")
        }
        
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "\(indexPath.row)")
        cell.backgroundColor = customization.whiteColour
        cell.textLabel?.text = arrayOfTitles[indexPath.row]
        tableView.rowHeight = 100
        
        cell.textLabel?.font = UIFont(name: "Helvetica Neue", size: 30)
        cell.textLabel?.textColor = customization.darkRedColour
        cell.detailTextLabel?.text = arrayOfDetails[indexPath.row]
        cell.detailTextLabel?.font = UIFont(name: "Helvetica Neue", size: 12)
        cell.detailTextLabel?.textColor = customization.lightRedColour
        return cell
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return 3
    }
    
}
