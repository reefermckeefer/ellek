//
//  ViewController.swift
//  Vintage Vitality
//
//  Created by Ellek Linton on 7/17/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import UIKit

class VitalsViewController: UIViewController, JBLineChartViewDelegate, JBLineChartViewDataSource {
    @IBOutlet weak var viewOfHeartRate: UIView!
    @IBOutlet weak var heartRateTitleLabel: UILabel!
    
    var customization = customizeView()
    var lineChartX = LineChartFunctionsX()
    var lineChartY = lineChartFunctionsY()
    
    var arrayOfHeartRateData = [110, 40, 140] as Array<CGFloat>
    var selectedDot = 6666666 as UInt
    var widthOfLines = CGFloat(4)
    var heartRateTitleSaved = UILabel()

    var heartRateLineGraph = JBLineChartView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        heartRateTitleSaved = heartRateTitleLabel
        customization.setColours(self)
        heartRateLineGraph.dataSource = self
        heartRateLineGraph.delegate = self
        
        var timer = NSTimer.scheduledTimerWithTimeInterval(3, target: self, selector: Selector("addToData"), userInfo: nil, repeats: true)
    }
    
    func addToData(){
        let random = CGFloat(arc4random_uniform(150) + 40)
            arrayOfHeartRateData.append(random)
            viewOfHeartRate.subviews.map({ $0.removeFromSuperview() })
            viewWillAppear(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    override func viewWillAppear(animated: Bool) {
        var padding = CGFloat(16)
        viewOfHeartRate.frame = CGRectMake(viewOfHeartRate.frame.minX, viewOfHeartRate.frame.minY, self.view.frame.width - 32, viewOfHeartRate.frame.height)
        heartRateTitleLabel = heartRateTitleSaved
        var frame = CGRectMake(padding * 3, heartRateTitleLabel.frame.maxY + padding, viewOfHeartRate.frame.width - (padding * 5), viewOfHeartRate.frame.height - padding * 3 - heartRateTitleLabel.frame.maxY)
        
        lineChartX.createGraph(viewOfHeartRate, delegate: self, chartView: heartRateLineGraph, dataSource: self, minimumValueOfY: 0, maximumValueOfY: nil, backgroundColour: customization.clearColour, tintColour: UIColor.greenColor(), frame: frame, data: arrayOfHeartRateData, radius: widthOfLines)
        lineChartY.createAxis(viewOfHeartRate, chartView: heartRateLineGraph, backgroundColour: customization.darkGreyColour, widthOfLine: widthOfLines, data: arrayOfHeartRateData)
    }
    
    
    
    func numberOfLinesInLineChartView(lineChartView: JBLineChartView!) -> UInt {
        return 1
    }
    
    func lineChartView(lineChartView: JBLineChartView!, numberOfVerticalValuesAtLineIndex lineIndex: UInt) -> UInt {
        return UInt(arrayOfHeartRateData.count)
    }
    
    func lineChartView(lineChartView: JBLineChartView!, verticalValueForHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> CGFloat {
        return arrayOfHeartRateData[Int(horizontalIndex)]
    }
    
    func lineChartView(lineChartView: JBLineChartView!, showsDotsForLineAtLineIndex lineIndex: UInt) -> Bool {
        return true
    }
    
    func lineChartView(lineChartView: JBLineChartView!, colorForDotAtHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> UIColor! {
        return customization.darkGreyColour
    }
    
    func lineChartView(lineChartView: JBLineChartView!, selectionColorForDotAtHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> UIColor! {
        return customization.darkRedColour
    }
    
    func lineChartView(lineChartView: JBLineChartView!, selectionColorForLineAtLineIndex lineIndex: UInt) -> UIColor! {
        return customization.darkGreyColour
    }
    
    func lineChartView(lineChartView: JBLineChartView!, dotRadiusForDotAtHorizontalIndex horizontalIndex: UInt, atLineIndex lineIndex: UInt) -> CGFloat {
        return widthOfLines
    }
    
    func lineChartView(lineChartView: JBLineChartView!, widthForLineAtLineIndex lineIndex: UInt) -> CGFloat {
        return widthOfLines / 1.5
    }
    
    func lineChartView(lineChartView: JBLineChartView!, lineStyleForLineAtLineIndex lineIndex: UInt) -> JBLineChartViewLineStyle {
        return JBLineChartViewLineStyle.Solid
    }
    
    func lineChartView(lineChartView: JBLineChartView!, smoothLineAtLineIndex lineIndex: UInt) -> Bool {
        return false
    }
    
    func lineChartView(lineChartView: JBLineChartView!, colorForLineAtLineIndex lineIndex: UInt) -> UIColor! {
        return customization.darkRedColour
    }
    
    func lineChartView(lineChartView: JBLineChartView!, didSelectLineAtIndex lineIndex: UInt, horizontalIndex: UInt, touchPoint: CGPoint) {
        selectedDot = horizontalIndex
        heartRateTitleLabel.text = "Heart Rate: \(Int(arrayOfHeartRateData[Int(horizontalIndex)]))"
        
    }
    
    func lineChartView(lineChartView: JBLineChartView!, verticalSelectionColorForLineAtLineIndex lineIndex: UInt) -> UIColor! {
        return customization.lightGreyColour
    }

}


