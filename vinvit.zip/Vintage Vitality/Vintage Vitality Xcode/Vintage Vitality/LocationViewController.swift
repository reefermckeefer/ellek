//
//  LocationViewController.swift
//  Vintage Vitality
//
//  Created by Ellek Linton on 7/22/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import UIKit
import MapKit

class LocationViewController: UIViewController {
    var customization = customizeView()
    var maps = mapFunctions()
    @IBOutlet weak var mapKitView: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        customization.setColours(self)
        maps.setCoordinate(mapKitView, latitude: 42.357107, longitude: -71.101516, regionRadius: 5280, title: "Mom's Location", subtitle: "Home for 3.4 hours")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
