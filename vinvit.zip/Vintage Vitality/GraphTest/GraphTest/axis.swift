//
//  EspressoLineForChart.swift
//  GraphTest
//
//  Created by Ellek Linton on 7/21/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import Foundation
import UIKit

class axis {
    
    func createXAxis(view: UIView, graphView: JBBarChartView, height: CGFloat, color: UIColor, goesOutsideOfGraph: Bool, incrementHeight: CGFloat, font: UIFont, arrayOfData: Array<CGFloat>) -> UILabel{
        var offset = height
        if (goesOutsideOfGraph == false){
            offset = 0
        }
        var label = UILabel(frame: CGRectMake(graphView.frame.minX, graphView.frame.maxY - offset, graphView.frame.width, height))
        label.backgroundColor = color
        view.addSubview(label)
        var howManyIncrements = graphView.dataSource.numberOfBarsInBarChartView(graphView)
        labelXAxis(view, graphView: graphView, barLabel: label, howManyIncrements: Int(howManyIncrements), widthOfIncrements: height, incrementHeight: incrementHeight, color: color, font: font, arrayOfData: arrayOfData)
        return label
    }
    
    func labelXAxis(view: UIView, graphView: JBBarChartView, barLabel: UILabel, howManyIncrements: Int, widthOfIncrements: CGFloat, incrementHeight: CGFloat, color: UIColor, font: UIFont, arrayOfData: Array<CGFloat>){
        var newHowManyIncrements = Int()
        if (howManyIncrements < 3){
            newHowManyIncrements = 3
        } else{//set increments to at least 3
        newHowManyIncrements = howManyIncrements
        }
        var padding = (Int(graphView.frame.width) / (howManyIncrements - 1))
            padding = (padding - (Int(widthOfIncrements) / howManyIncrements))
        var lastLabel = UILabel(frame: CGRectMake(barLabel.frame.minX - CGFloat(padding), barLabel.frame.maxY, barLabel.frame.width, barLabel.frame.height))
        var arrayOfLabels = Array<UILabel>()
        for x in 1...newHowManyIncrements{
            var newLabel = UILabel(frame: CGRectMake(lastLabel.frame.minX + CGFloat(padding), lastLabel.frame.minY, widthOfIncrements, incrementHeight))
                newLabel.backgroundColor = color
            if (x == newHowManyIncrements){
                newLabel = UILabel(frame: CGRectMake(barLabel.frame.maxX - widthOfIncrements, lastLabel.frame.minY, widthOfIncrements, incrementHeight))
                newLabel.backgroundColor = color
                arrayOfLabels.append(newLabel)
            } else {
                arrayOfLabels.append(newLabel)
            }
            newLabel.center.x = graphView.barViewAtIndex(UInt(x) - 1).center.x + graphView.frame.minX
            lastLabel = newLabel
            view.addSubview(newLabel)
        }
            detailXAxis(arrayOfLabels, incrementSize: 1, color: color, view: view, font: font, graphView: graphView, arrayOfData: arrayOfData)
    }
    
    func detailXAxis(arrayOfLabelIncrements: Array<UILabel>, incrementSize: Int, color: UIColor, view: UIView, font: UIFont, graphView: JBBarChartView, arrayOfData: Array<CGFloat>){
        for (index, label) in enumerate(arrayOfLabelIncrements){
            var labelDetail = UILabel(frame: CGRectMake(0, 0, 50, 50))
                labelDetail.backgroundColor = UIColor.clearColor()
                labelDetail.textColor = color
                labelDetail.font = font
                labelDetail.text = String(stringInterpolationSegment: arrayOfData[index])
                labelDetail.sizeToFit()
                labelDetail.center = label.center//graphView.barViewAtIndex(UInt(index)).center
                labelDetail.center.y = label.frame.maxY + 10
                view.addSubview(labelDetail)
        }
    }
    
    
    
    
    func createYAxis(view: UIView, graphView: UIView, width: CGFloat, color: UIColor, goesOutsideOfGraph: Bool) -> UILabel{
        var offset = width
        if (goesOutsideOfGraph == false){
            offset = 0
        }
        var label = UILabel(frame: CGRectMake(graphView.frame.minX - offset, graphView.frame.minY, width, graphView.frame.height))
        label.backgroundColor = color
        view.addSubview(label)
        return label
    }
    
}