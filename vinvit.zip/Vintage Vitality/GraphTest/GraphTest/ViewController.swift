//
//  ViewController.swift
//  GraphTest
//
//  Created by Ellek Linton on 7/20/15.
//  Copyright (c) 2015 EspressoAppDev. All rights reserved.
//

import UIKit
import Foundation


class ViewController: UIViewController, JBBarChartViewDelegate, JBBarChartViewDataSource {
    var theChartView = JBBarChartView()
    var arrayOfHeights = [500.5, 200.6, 50, 300, 700] as Array<CGFloat>
    var theAxis = axis()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        theChartView.delegate = self
        
        theChartView.dataSource = self
        theChartView.frame = CGRectMake(100, 100, 200, 500)
        theChartView.minimumValue = 0
        theChartView.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(theChartView)
        theChartView.reloadData()
        UIColor(red: 0xff, green: 0xff, blue: 0xff, alpha: 1)
        theAxis.createXAxis(self.view, graphView: theChartView, height: 5, color: UIColor.blackColor(), goesOutsideOfGraph: true, incrementHeight: 20, font: UIFont(name: "Helvetica Neue", size: 10)!, arrayOfData: arrayOfHeights)
//        theAxis.createYAxis(self.view, graphView: theChartView, width: 5, color: UIColor.blackColor(), goesOutsideOfGraph: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfBarsInBarChartView(barChartView: JBBarChartView!) -> UInt {
        return UInt(arrayOfHeights.count)
    }
    
    func barChartView(barChartView: JBBarChartView!, heightForBarViewAtIndex index: UInt) -> CGFloat {
    return arrayOfHeights[Int(index)]
    }
    
    func barChartView(barChartView: JBBarChartView!, colorForBarViewAtIndex index: UInt) -> UIColor! {
        return UIColor(red: 163/255, green: 30/255, blue: 34/255, alpha: 1)
    }
    
    func barChartView(barChartView: JBBarChartView!, didSelectBarAtIndex index: UInt) {
        barChartView.barViewAtIndex(index).backgroundColor = UIColor.grayColor()
      //  barChartView.barViewAtIndex(index).c
        barChartView.reloadData()
    }


}

